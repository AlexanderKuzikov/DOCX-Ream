const fs = require('fs');
const path = require('path');

console.log('\n--- 🕵️ НАЧИНАЕМ ДИАГНОСТИКУ ---');

// 1. Где мы находимся?
const cwd = process.cwd();
console.log(`1. Рабочая директория (откуда запущен скрипт):`);
console.log(`   👉 ${cwd}`);

// 2. Ищем папку data
const dataDir = path.join(cwd, 'data');
console.log(`\n2. Проверяем папку data по пути:`);
console.log(`   👉 ${dataDir}`);

if (!fs.existsSync(dataDir)) {
    console.error('   ❌ ОШИБКА: Папка data вообще не найдена!');
    console.log('      Убедитесь, что запускаете скрипт из корня проекта.');
    process.exit(1);
} else {
    console.log('   ✅ Папка найдена.');
}

// 3. Сканируем файлы (Ищем скрытые символы и расширения)
console.log(`\n3. Содержимое папки data (точное имя файла):`);
const files = fs.readdirSync(dataDir);

if (files.length === 0) {
    console.error('   ❌ Папка пустая!');
}

files.forEach(file => {
    // Выводим имя в кавычках, чтобы увидеть пробелы по краям
    console.log(`   📄 "${file}"`);
    
    // Проверка на частые ошибки
    if (file === 'scenario_1.json.json') console.error('      🔴 ОШИБКА: Двойное расширение (.json.json)! Переименуйте файл.');
    if (file.includes(' ')) console.warn('      ⚠️ Внимание: В имени есть пробелы.');
    if (file.toLowerCase() !== file) console.warn('      ⚠️ Внимание: В имени есть заглавные буквы (Linux/Mac чувствительны к этому).');
});

// 4. Тест конкретного файла из вашего Манифеста
const targetName = 'scenario_1.json';
const targetPath = path.join(dataDir, targetName);

console.log(`\n4. Пробуем прочитать тестовый файл: ${targetName}`);
if (fs.existsSync(targetPath)) {
    console.log(`   ✅ Файл найден.`);
    try {
        const content = fs.readFileSync(targetPath, 'utf8');
        // Проверка на BOM (Byte Order Mark) - невидимый символ в начале
        if (content.charCodeAt(0) === 0xFEFF) {
            console.warn('   ⚠️ Обнаружен BOM (невидимый символ). Это может ломать JSON.parse. Пересохраните файл в UTF-8 без BOM.');
        }
        JSON.parse(content);
        console.log(`   ✅ JSON валиден и готов к работе.`);
    } catch (e) {
        console.error(`   ❌ Файл есть, но JSON битый: ${e.message}`);
    }
} else {
    console.error(`   ❌ Файл НЕ НАЙДЕН системой по пути:`);
    console.error(`      ${targetPath}`);
    console.error(`      Сравните этот путь с тем, где реально лежит файл.`);
}

console.log('\n--- ДИАГНОСТИКА ЗАВЕРШЕНА ---\n');
